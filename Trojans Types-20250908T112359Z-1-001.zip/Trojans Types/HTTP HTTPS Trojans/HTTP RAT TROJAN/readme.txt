[HTTP_RAT 0.31]_______________________________________________

coded in C.
works on win9x/2000/xp

[What is it]_________________________________________________

HTTP_RAT is a "web-server" that allows you to browse victim's
computer with any browser on any OS(!). It sends victim's ip 
adress to your email adress, so u have just to open 
http://his_ip[:port] in your browser.

[How to use]__________________________________________________

Run httprat.exe, fill in your email addresss & smtp server(s)
and click [Create]. It will make a file called httpserver.exe.
Send that file to victim.
When victim opens it u'll get mail with instructions.

[Features]____________________________________________________

server size: 30kb
view/kill processes
browse/download/execute/delete files
close firewalls b4 running
hmm.. that's all 4 now ;]

these will be added in next version:

file uploading
screen capture
registry editing(maybe)
better hiding/startup methods
automatically find smtp server
[something useful that u can suggest]

[Contact]_____________________________________________________

send any suggestions/bug reports to: zombie@freenet.am
or leave comments in guestbook at my hp :]

latest version is available at: http://freenet.am/~zombie




